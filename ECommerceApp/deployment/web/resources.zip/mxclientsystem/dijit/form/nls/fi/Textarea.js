//>>built
define("dijit/form/nls/fi/Textarea",({iframeEditTitle:"muokkausalue",iframeFocusTitle:"muokkausalueen kehys"}));
