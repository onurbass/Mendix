//>>built
define("dijit/nls/hu/common",({buttonOk:"OK",buttonCancel:"Mégse",buttonSave:"Mentés",itemClose:"Bezárás"}));
